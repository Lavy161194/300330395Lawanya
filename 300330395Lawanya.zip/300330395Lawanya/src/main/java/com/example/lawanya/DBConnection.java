package com.example.lawanya;

import org.springframework.stereotype.Service;

import java.sql.DriverManager;
import java.sql.SQLException;

@Service
public class DBConnection {
    public java.sql.Connection connect() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        java.sql.Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/savings?enabledTLSProtocols=TLSv1.2&characterEncoding=latin1&useConfigs=maxPerformance", "root", "password");
        return con1;
    }
}