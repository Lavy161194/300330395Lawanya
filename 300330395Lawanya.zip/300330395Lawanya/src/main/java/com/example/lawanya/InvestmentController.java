package com.example.lawanya;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@SessionAttributes({"id", "desc", "errMsg", "errorMessage"})
@RequestMapping
@Controller
public class InvestmentController {
    DatabaseService dbservice;

    @Autowired
    DBConnection connect;

    @RequestMapping(value = "/investment", method = RequestMethod.GET)
    public String showInvestmentpage(ModelMap model, @RequestParam(defaultValue = "") String id) throws ClassNotFoundException, SQLException {
        dbservice = new DatabaseService(connect.connect());
        model.addAttribute("todo", dbservice.display());
//        List<Category> filteredTodos = new ArrayList<Category>();
//        filteredTodos = (List) model.get("todo");
//        model.put("id", filteredTodos.get(0).getCatcode());
//        model.put("desc", filteredTodos.get(0).getCatdesc());
        return "investment";
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String showInvestmentpage2(ModelMap model, @RequestParam(defaultValue = "") String id) throws ClassNotFoundException, SQLException {
        dbservice = new DatabaseService(connect.connect());
        model.addAttribute("todo", dbservice.display());
//        List<Category> filteredTodos = new ArrayList<Category>();
//        filteredTodos = (List) model.get("todos");
//        model.put("id", filteredTodos.get(0).getCatcode());
//        model.put("desc", filteredTodos.get(0).getCatdesc());
        return "investment";
    }

    @RequestMapping(value = "/add-inv", method = RequestMethod.POST)
    public String addinv(ModelMap model, @RequestParam int customer_number, @RequestParam String customer_name,@RequestParam double customer_deposit,@RequestParam int noYears, @RequestParam String saveings_type) throws SQLException, ClassNotFoundException {
        if (!((dbservice.search(customer_number)) == null)) {
            model.put("errorMessage", "Record Existing");
            return "redirect:/investment";
        }
        Investment investment = new Investment(customer_number,customer_name,customer_deposit,noYears,saveings_type);
        dbservice.add(investment);
        model.clear();
        return "redirect:/investment";
    }

    @RequestMapping(value = "/update-todo", method = RequestMethod.GET)
    public String showUpdateTodoPage(ModelMap model, @RequestParam int customer_number) throws SQLException, ClassNotFoundException {
        model.put("id", customer_number);
        Investment cc = dbservice.search(customer_number);
        model.put("id", cc.getCustomer_number());
        model.put("desc", cc.getCustomer_name());
        return "catedit";
    }

    @RequestMapping(value = "/update-todo", method = RequestMethod.POST)
    public String showUpdate(ModelMap model, @RequestParam int customer_number, @RequestParam String customer_name,@RequestParam double customer_deposit,@RequestParam int noYears, @RequestParam String saveings_type) throws SQLException, ClassNotFoundException {
        //get the old catcode
        int iid = (Integer) model.get("id");
        Investment cc = new Investment(customer_number,customer_name,customer_deposit,noYears,saveings_type);
        dbservice.edit(cc, iid);
        return "redirect:/";
    }

    @RequestMapping(value = "/delete-todo", method = RequestMethod.GET)
    public String deleteTodo(ModelMap model, @RequestParam int customer_number) throws SQLException, ClassNotFoundException {
        dbservice.delete(customer_number);
        model.clear();
        return "redirect:/";
    }

    @RequestMapping(value = "/see-todo", method = RequestMethod.GET)
    public String seetodo(ModelMap
                                  model, @RequestParam int customer_number) throws SQLException, ClassNotFoundException {
        model.put("id", customer_number);
        dbservice = new DatabaseService(connect.connect());
        Integer iid = (Integer) model.get("id");
        List<Investment> Itemlist = new ArrayList<>();
        Itemlist = dbservice.display2(iid);
        if (Itemlist.size() == 0) {
            model.put("errorMessage", "There are not items for this category ");
            return "redirect:/";
        }
        model.put("desc", iid);
        System.out.println(iid);
        model.addAttribute("todos1", dbservice.display2(iid));
        return "items";
    }

    @RequestMapping(value = "/see-todo", method = RequestMethod.POST)
    public String seetodo2(ModelMap model) throws
            SQLException, ClassNotFoundException {
        return "redirect:/";
    }
}
