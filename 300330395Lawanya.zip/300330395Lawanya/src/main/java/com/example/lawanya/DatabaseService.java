package com.example.lawanya;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseService implements DatabaseInterface {

    Connection con;

    public DatabaseService(Connection con) {
        this.con = con;
    }

    @Override
    public void add(Investment investment) throws ClassNotFoundException, SQLException {
        String sqlQuery = "INSERT INTO savingstable VALUES ( ?, ?,?,?,? )";
        PreparedStatement query = con.prepareStatement(sqlQuery);
        query.setInt(1, investment.getCustomer_number());
        query.setString(2, investment.getCustomer_name());
        query.setDouble(3, investment.getCustomer_deposit());
        query.setInt(4, investment.getNoYears());
        query.setString(5, investment.getSaveings_type());
        query.executeUpdate();
    }

    @Override
    public Investment edit(Investment investment, int customer_number) throws SQLException, ClassNotFoundException {
        PreparedStatement query;
        query = con.prepareStatement("Update savingstable set custname=?, cdep=?,nyears=?,savtype=? where custno = ?");
        query.setString(1, investment.getCustomer_name());
        query.setDouble(2, investment.getCustomer_deposit());
        query.setInt(3, investment.getNoYears());
        query.setString(4, investment.getSaveings_type());
        query.setInt(5, investment.getCustomer_number());
        query.executeUpdate();
        return investment;
    }

    @Override
    public void delete(int customer_number) throws SQLException {
        String sqlQuery = "Delete from savingstable where custno = ?";
        PreparedStatement query = con.prepareStatement(sqlQuery);
        query.setInt(1, customer_number);
        query.executeUpdate();
    }

    public Investment search(int customer_number) throws SQLException, ClassNotFoundException {
        String sqlquery = "Select * from savingstable where custno = ?";
        PreparedStatement query = con.prepareStatement(sqlquery);
        query.setInt(1, customer_number);
        ResultSet rs = query.executeQuery();
        if (!rs.first()) {
            System.out.print("Record not existing");
            return null;
        }
        Investment investment = new Investment(rs.getInt("custno"),rs.getString("custname"),rs.getDouble("cdep"),rs.getInt("nyears"),rs.getString("savtype"));
        return investment;
    }

    @Override
    public List<Investment> display() throws ClassNotFoundException, SQLException {
        //create an array list that will contain the data recovered
        List<Investment> invlist = new ArrayList<Investment>();
        String quer1 = "Select * from savingstable";
        PreparedStatement query = con.prepareStatement(quer1);
        ResultSet rs = query.executeQuery();
        Investment inv; //display records if there is data;
        while (rs.next()) {
            inv = new Investment(rs.getInt("custno"),rs.getString("custname"),rs.getDouble("cdep"),rs.getInt("nyears"),rs.getString("savtype"));
            invlist.add(inv);
        }
        return invlist;
    }

    public List<Investment> display2(int customer_number) throws ClassNotFoundException, SQLException {
        //create an array list that will contain the data recovered
        List<Investment> Itemlist = new ArrayList<Investment>();
        String quer1 = "Select * from savingstable where custno = ?";
        PreparedStatement query = con.prepareStatement(quer1);
        query.setInt(1, customer_number);
        ResultSet rs = query.executeQuery();
        Investment obj2;
        //display records if there is data;
        while (rs.next()) {
            obj2 = new Investment(rs.getInt("custno"),rs.getString("custname"),rs.getDouble("cdep"),rs.getInt("nyears"),rs.getString("savtype"));
            Itemlist.add(obj2);
        }
        return Itemlist;
    }
}