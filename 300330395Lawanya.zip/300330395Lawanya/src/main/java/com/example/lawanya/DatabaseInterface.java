package com.example.lawanya;

import java.sql.SQLException;
import java.util.List;

public interface DatabaseInterface {
    public void add(Investment investment) throws ClassNotFoundException, SQLException;

    public Investment edit(Investment investment, int customer_number) throws SQLException, ClassNotFoundException;

    public void delete(int customer_number) throws SQLException;

    public List<Investment> display() throws ClassNotFoundException, SQLException;
}
