package com.example.lawanya;

public class Investment {

    int customer_number;
    String customer_name;
    double customer_deposit;
    int noYears;
    String saveings_type;

    public Investment(int customer_number, String customer_name, double customer_deposit, int noYears, String saveings_type) {
        this.customer_number = customer_number;
        this.customer_name = customer_name;
        this.customer_deposit = customer_deposit;
        this.noYears = noYears;
        this.saveings_type = saveings_type;
    }

    public Investment(int customer_number) {
        this.customer_number = customer_number;
    }

    public int getCustomer_number() {
        return customer_number;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public double getCustomer_deposit() {
        return customer_deposit;
    }

    public int getNoYears() {
        return noYears;
    }

    public String getSaveings_type() {
        return saveings_type;
    }

    public void setCustomer_number(int customer_number) {
        this.customer_number = customer_number;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public void setCustomer_deposit(double customer_deposit) {
        this.customer_deposit = customer_deposit;
    }

    public void setNoYears(int noYears) {
        this.noYears = noYears;
    }

    public void setSaveings_type(String saveings_type) {
        this.saveings_type = saveings_type;
    }
}
